<?php include('header.php'); ?>

<?php include('admin/function.php'); ?>



	<!-- this is for donor registraton -->
	<div class="main_content" style="background-color:#fff;">
		<h2 class="text-center" style="background-color:#272327;color: #fff;padding: 5px;">Choose Your Login</h2>
		<div class="col-md-12">
			<div class="box1" style="float: left;margin-left: 325px;">
				<h4 class="text-center;" ><a href="patient_login.php" style="text-decoration: none;color:red;">I am Patient</a></h4>
			</div>
			
			<div class="box2" style="float: right;margin-right: 385px;">
				<h4 class="text-center;"><a href="#" style="text-decoration: none;color:red;">I am Doctor</a></h4>
			</div>
			
		</div>



		
          
    </div><br><br><br><br>
		
	
	
	

	
 <?php include('footer.php'); ?>


	
	</div><!--  containerFluid Ends -->




	<script src="js/bootstrap.min.js"></script>





	
</body>
</html>